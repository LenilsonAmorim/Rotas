# Rota Inteligente — memória por cidade

Versão para GitHub Pages. A memória de nomes/apelidos fica no navegador usando localStorage e é separada por cidade.

Fluxo:
1. Defina a cidade.
2. Use GPS como partida.
3. Cole/importa a planilha.
4. O sistema procura primeiro as associações que você ensinou.
5. O que não encontrar pode ser localizado no mapa.
6. A rota é calculada pela malha viária com OSRM.
7. A sequência final pode ser copiada ou baixada.

Importante: a memória é local ao navegador/aparelho. Se limpar os dados do navegador ou trocar de aparelho, as associações não acompanham. A próxima evolução pode exportar/importar a memória ou sincronizá-la online.

A geocodificação usa Nominatim público para protótipo, respeitando intervalo entre consultas. Para uso frequente/comercial e listas grandes, recomenda-se migrar para um provedor/servidor de geocodificação adequado e com cache.
