# Rota de Endereços — GitHub Pages

Protótipo de aplicativo web para:
- usar a localização atual do celular como partida;
- importar CSV/TXT/XLSX;
- colar um endereço por linha;
- geocodificar os endereços;
- calcular uma sequência de visita com OSRM;
- mostrar a rota no mapa;
- copiar a sequência;
- baixar um CSV/XLSX simples com a ordem.

## Publicar no GitHub Pages

1. Crie um repositório no GitHub.
2. Envie `index.html`, `style.css` e `app.js`.
3. Em Settings → Pages, selecione a branch principal e a pasta raiz.
4. Abra o endereço do GitHub Pages no celular.
5. Autorize a localização quando solicitado.

## Observações importantes

- O protótipo usa Nominatim público para geocodificação e respeita 1 requisição/segundo entre consultas.
- Para uso frequente/comercial ou muitas linhas, substitua a geocodificação pública por um provedor adequado ou por uma instância própria, com cache.
- O OSRM calcula a ordem da viagem, mas a qualidade depende da precisão dos endereços encontrados.
- A planilha importada atualmente usa a primeira célula não vazia de cada linha como endereço. A versão seguinte pode permitir escolher a coluna de endereço e preservar todas as colunas da linha original.
