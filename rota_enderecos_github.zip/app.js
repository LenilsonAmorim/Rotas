let start = null;
let rows = [];
let geocoded = [];
let lastRoute = null;
let map = null;
let markers = [];

const $ = id => document.getElementById(id);

function status(id, text, cls=""){ $(id).textContent=text; $(id).className="status "+cls; }

$("locationBtn").onclick = () => {
  if (!navigator.geolocation) {
    status("locationStatus","Este navegador não oferece geolocalização.","bad"); return;
  }
  status("locationStatus","Obtendo sua localização...");
  navigator.geolocation.getCurrentPosition(
    p => {
      start = {lat:p.coords.latitude, lon:p.coords.longitude};
      status("locationStatus",`Localização definida: ${start.lat.toFixed(5)}, ${start.lon.toFixed(5)}`,"ok");
    },
    e => status("locationStatus","Não foi possível obter a localização. Autorize o GPS e tente novamente.","bad"),
    {enableHighAccuracy:true, timeout:15000, maximumAge:60000}
  );
};

$("fileInput").onchange = async e => {
  const f = e.target.files[0];
  if (!f) return;
  try {
    const name = f.name.toLowerCase();
    if (name.endsWith(".xlsx") || name.endsWith(".xls")) {
      const data = await f.arrayBuffer();
      const wb = XLSX.read(data,{type:"array"});
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const arr = XLSX.utils.sheet_to_json(sheet,{header:1,defval:""});
      // Usa a primeira coluna que tenha conteúdo por linha.
      rows = arr.map((r,i)=>({original:i+1,text:(r.find(v=>String(v).trim()!=="")||"").toString().trim()}))
                .filter(x=>x.text);
    } else {
      const txt = await f.text();
      rows = txt.split(/\r?\n/).map((t,i)=>({original:i+1,text:t.trim()})).filter(x=>x.text);
    }
    renderInputStatus();
  } catch(err){ status("inputStatus","Erro ao ler o arquivo: "+err.message,"bad"); }
};

$("loadBtn").onclick = () => {
  const text = $("addressText").value.trim();
  if (text) rows = text.split(/\r?\n/).map((t,i)=>({original:i+1,text:t.trim()})).filter(x=>x.text);
  renderInputStatus();
};

$("clearBtn").onclick = () => {
  rows=[]; geocoded=[]; lastRoute=null; $("addressText").value=""; $("fileInput").value="";
  $("results").innerHTML=""; $("summary").textContent=""; status("inputStatus","");
  if(map){map.remove();map=null}
};

function renderInputStatus(){
  status("inputStatus",`${rows.length} endereço(s) carregado(s).`);
}

function sleep(ms){return new Promise(r=>setTimeout(r,ms));}

async function geocodeAddress(text){
  const key="geo:"+text.toLowerCase();
  const cached=localStorage.getItem(key);
  if(cached) return JSON.parse(cached);
  const url="https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=br&q="+encodeURIComponent(text);
  const r=await fetch(url,{headers:{"Accept":"application/json"}});
  if(!r.ok) throw new Error("Falha no serviço de localização");
  const data=await r.json();
  if(!data.length) return null;
  const point={lat:Number(data[0].lat),lon:Number(data[0].lon),display:data[0].display_name};
  localStorage.setItem(key,JSON.stringify(point));
  return point;
}

async function geocodeAll(){
  geocoded=[];
  for(let i=0;i<rows.length;i++){
    status("routeStatus",`Localizando endereço ${i+1} de ${rows.length}...`);
    const point=await geocodeAddress(rows[i].text);
    geocoded.push({...rows[i],point});
    if(i<rows.length-1) await sleep(1050);
  }
}

async function calculate(){
  if(!start){ status("routeStatus","Primeiro toque em “Usar minha localização atual”.","bad"); return; }
  if(!rows.length){ status("routeStatus","Carregue os endereços primeiro.","bad"); return; }
  $("routeBtn").disabled=true;
  try{
    await geocodeAll();
    const missing=geocoded.filter(x=>!x.point);
    if(missing.length){
      status("routeStatus",`${missing.length} endereço(s) não foram localizados. Corrija-os e tente novamente.`,"bad");
      renderResults([]);
      return;
    }
    // OSRM Trip: origem + pontos. source=first garante a localização atual como origem.
    // roundtrip=false deixa o último ponto como destino final.
    const coords=[`${start.lon},${start.lat}`,...geocoded.map(x=>`${x.point.lon},${x.point.lat}`)].join(";");
    const url=`https://router.project-osrm.org/trip/v1/driving/${coords}?source=first&roundtrip=false&overview=full&geometries=geojson&steps=true`;
    status("routeStatus","Calculando a sequência...");
    const r=await fetch(url);
    if(!r.ok) throw new Error("Falha no cálculo da rota");
    const data=await r.json();
    if(data.code!=="Ok") throw new Error(data.message||"Rota não encontrada");
    lastRoute=data;
    // waypoint_index identifica a ordem otimizada de cada coordenada.
    const orderedWaypoints=data.waypoints.slice(1).sort((a,b)=>a.waypoint_index-b.waypoint_index);
    const ordered=orderedWaypoints.map(w=>geocoded[w.waypoint_index-1]);
    renderResults(ordered);
    renderMap(data,ordered);
    const km=(data.routes[0].distance/1000).toFixed(1);
    const min=Math.round(data.routes[0].duration/60);
    $("summary").textContent=`${ordered.length} paradas · ${km} km · aproximadamente ${min} min`;
    status("routeStatus","Rota calculada com sucesso.","ok");
  }catch(err){
    status("routeStatus","Erro: "+err.message,"bad");
  }finally{$("routeBtn").disabled=false;}
}

function renderResults(list){
  $("results").innerHTML=list.map((x,i)=>`
    <div class="stop">
      <div class="num">${i+1}</div>
      <div><b>${escapeHtml(x.text)}</b><small>Linha original: ${x.original}</small></div>
    </div>`).join("");
}

function renderMap(data,ordered){
  if(map) map.remove();
  map=L.map("map").setView([start.lat,start.lon],14);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:19,attribution:"&copy; OpenStreetMap contributors"}).addTo(map);
  const route=L.geoJSON(data.routes[0].geometry).addTo(map);
  L.marker([start.lat,start.lon]).addTo(map).bindPopup("Partida atual").openPopup();
  ordered.forEach((x,i)=>L.marker([x.point.lat,x.point.lon]).addTo(map).bindPopup(`${i+1} - ${escapeHtml(x.text)}`));
  map.fitBounds(route.getBounds(),{padding:[20,20]});
}

function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[c]));}

$("routeBtn").onclick=calculate;

$("copyBtn").onclick=async ()=>{
  const items=[...$("results").querySelectorAll(".stop")].map((e,i)=>`${i+1}. ${e.querySelector("b").textContent}`);
  if(!items.length) return;
  await navigator.clipboard.writeText(items.join("\n"));
  status("routeStatus","Sequência copiada.","ok");
};

$("downloadBtn").onclick=()=>{
  if(!lastRoute) return;
  const ordered=[...$("results").querySelectorAll(".stop")].map((e,i)=>({ORDEM:i+1,ENDERECO:e.querySelector("b").textContent}));
  const ws=XLSX.utils.json_to_sheet(ordered);
  const wb=XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb,ws,"Rota");
  XLSX.writeFile(wb,"rota_organizada.xlsx");
};
